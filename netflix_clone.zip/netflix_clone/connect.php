<?php

$conn = mysqli_connect('localhost','root','','netflix');
if(!$conn)
{
    echo "Connection Successfull";
}

?>
