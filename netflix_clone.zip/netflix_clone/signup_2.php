

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>create password</title>
    <link rel="stylesheet" href="css/signup.css">
</head>
<body>
    <div class="header">
        <nav>
            <img src="images/logo.png" alt="404 not found" class="logo">
           <div>
            <button> <a href="login.php">Sign in </a><img src="" alt=""></button>
        </div>
        </nav>
        <div class="header-content">
            <div id="bg-img"></div>
            <h1>Create password to your account</h1><br>
            <form action="" class="email-signup" method="post">
            <input type="email" placeholder="E M A I L" name="email"required>
                <input type="password" placeholder="P A S S W O R D" name="password"required>
            <button type="submit" name="submit">submit</button>
            </form>
            <?php
    include("connect.php");
    if(isset($_POST['submit']))
    {
        $email=$_POST['email'];
    $password=$_POST['password'];

    $duplicate = mysqli_query($conn, "select * from fulldata where email = '$email'");
    if(mysqli_num_rows($duplicate) > 0){
        echo
        "<script> alert('Email is already taken')</script>";
    }
    else{

    $sql="insert into `fulldata`(email,password)
    values('$email','$password')";
    $result=mysqli_query($conn,$sql);
    if($result){
        echo
        "<script> alert('ACCOUNT CREATED SUCCESSFULLY')</script>";
        header('location:login.php');
    }
    else{

        echo'error';
    }
    }
}
    ?>
</body>
</html>