
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>netflix Signup</title>
    <link rel="stylesheet" href="css/signup.css">
</head>
<body>
    <div class="header">
        <nav>
            <img src="images/logo.png" alt="404 not found" class="logo">
           <div>
            <button> <a href="login.php">Sign in </a><img src="" alt=""></button>
        </div>
        </nav>
        <div class="header-content">
            <div id="bg-img"></div>
            <h1>Finish setting up your account</h1><br>
            <h3>Netflix is personalised for you. Create a password to watch on any device at any time.</h3>
            <form action="" class="email-signup">
            <button type="submit"><a href="signup_2.php">Next</a></button>
            </form>
        </div>
</body>
</html>