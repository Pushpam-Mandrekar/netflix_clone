
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Netflix Sign in Page</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <div class="logo">
        <img src="images/logo_01.png" alt="">
    </div>

    <div class="container">
        <h1>Sign In</h1>
        <form method="post">
            <input type="email" placeholder="Email or phone number" name="email">
            <input type="password" placeholder="Password" name="password">
            <input type="submit" value="submit" name="submit">
            <input type="checkbox">
            <label>Remember me</label>
            <a href="#">Need help?</a>
        </form>
        <div class="content">
            <h2>New to Netflix? <a href="signup.php">Sign up now.</a> </h2> <br>
            <h2>This page is protected by Google reCAPTCHA to ensure you're not a bot. Learn more.</h2>
        </div>
    </div>

    <?php
    
    include("connect.php");
        if(isset($_POST["submit"])){
            $email = $_POST["email"];
            $password = $_POST["password"];
            $result = mysqli_query($conn, "select * from fulldata where email = '$email' or password = '$password'");
            $row = mysqli_fetch_assoc($result);
            if(mysqli_num_rows($result) > 0){
                if($password == $row["password"]){
                    $_SESSION["login"] = true;
                    $_SESSION["id"] = $row["id"];
                    header("Location: dashboard.html");
                }
                else{
                    echo
                "<script> alert('wrong password '); </script>";
                }
            }
            else{
                echo
                "<script> alert('User not Registered'); </script>";
            }
        }

    ?>


</body>
</html>